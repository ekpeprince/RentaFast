'use client';

import * as React from 'react';
import { notFound, useRouter } from 'next/navigation';
import Image from 'next/image';
import { ShieldCheck, BedDouble, Bath, Building, ArrowLeft, Phone, User as UserIcon, Eye, Star, Loader2 } from 'lucide-react';
import { useDoc, useFirestore, useMemoFirebase, useUser } from '@/firebase';
import { doc, collection, query, where, getDocs, addDoc, serverTimestamp, increment } from 'firebase/firestore';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { formatCurrency } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Badge } from '@/components/ui/badge';
import AmenityIcon from '@/components/amenity-icon';
import RentNowDialog from '@/components/rent-now-dialog';
import ReviewSection from '@/components/review-section';
import type { Property, UserProfile } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { updateDocumentNonBlocking } from '@/firebase/non-blocking-updates';

function PropertyDetailsSkeleton() {
  return (
    <div className="relative min-h-screen pb-28">
       <Skeleton className="h-72 w-full sm:h-96" />
        <div className="container mx-auto -mt-16 px-4 sm:px-6 lg:px-8">
          <div className="relative space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <Skeleton className="h-8 w-80 mb-2" />
                    <Skeleton className="h-5 w-48" />
                  </div>
                  <Skeleton className="h-8 w-32 mt-2 sm:mt-0" />
                </div>
              </CardHeader>
              <CardContent>
                <Skeleton className="h-6 w-40 mb-2" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
    </div>
  )
}

export default function PropertyPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = React.use(params);
  const id = resolvedParams.id;
  
  const { user } = useUser();
  const firestore = useFirestore();
  const router = useRouter();
  const [isStartingChat, setIsStartingChat] = useState(false);

  const propertyRef = useMemoFirebase(
    () => (firestore && id ? doc(firestore, 'properties', id) : null),
    [firestore, id]
  );
  const { data: property, isLoading } = useDoc<Property>(propertyRef);

  // Increment view count on mount
  useEffect(() => {
    if (firestore && id) {
      const docRef = doc(firestore, 'properties', id);
      updateDocumentNonBlocking(docRef, {
        viewCount: increment(1)
      });
    }
  }, [firestore, id]);

  // Fetch landlord info
  const landlordRef = useMemoFirebase(
    () => (firestore && property ? doc(firestore, 'users', property.landlordId) : null),
    [firestore, property?.landlordId]
  );
  const { data: landlord, isLoading: isLandlordLoading } = useDoc<UserProfile>(landlordRef);

  const handleStartChat = async () => {
    if (!user || !firestore || !property) {
      if (!user) router.push('/login');
      return;
    }

    setIsStartingChat(true);

    try {
      const chatsRef = collection(firestore, 'chats');
      const q = query(
        chatsRef, 
        where('participants', 'array-contains', user.uid),
        where('propertyId', '==', property.id)
      );
      
      const querySnapshot = await getDocs(q);
      let chatId = '';

      if (!querySnapshot.empty) {
        chatId = querySnapshot.docs[0].id;
      } else {
        const newChat = {
          participants: [user.uid, property.landlordId],
          propertyId: property.id,
          propertyTitle: property.title,
          lastMessage: 'Conversation started',
          updatedAt: serverTimestamp(),
        };
        const docRef = await addDoc(chatsRef, newChat);
        chatId = docRef.id;
      }

      router.push(`/chat/${chatId}`);
    } catch (error) {
      console.error('Error starting chat:', error);
    } finally {
      setIsStartingChat(false);
    }
  };

  // If loading, show skeleton.
  if (isLoading || (firestore && !propertyRef)) {
    return <PropertyDetailsSkeleton />;
  }

  // Definitively check for non-existent property AFTER loading is complete.
  if (!isLoading && property === null) {
    notFound();
    return null;
  }

  // At this point, property must be defined.
  if (!property) return <PropertyDetailsSkeleton />;

  const propertyImages = property.imageUrls && property.imageUrls.length > 0 
    ? property.imageUrls 
    : [(PlaceHolderImages.find((img) => img.id === 'mcc-apartment') || PlaceHolderImages[0]).imageUrl];

  const isOwner = user?.uid === property.landlordId;

  return (
    <div className="relative min-h-screen pb-28 bg-muted/5">
      <div className="absolute top-4 left-4 z-20">
        <Button asChild variant="secondary" size="icon" className="rounded-full shadow-lg bg-white/80 backdrop-blur-sm">
          <Link href="/">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
      </div>

      <div className="relative h-72 w-full sm:h-[500px] bg-black">
        <Carousel className="w-full h-full">
          <CarouselContent>
            {propertyImages.map((url, index) => (
              <CarouselItem key={index} className="relative h-72 sm:h-[500px] w-full">
                <Image
                  src={url}
                  alt={`${property.title} - Image ${index + 1}`}
                  fill
                  className="object-cover"
                  priority={index === 0}
                />
              </CarouselItem>
            ))}
          </CarouselContent>
          {propertyImages.length > 1 && (
            <>
              <CarouselPrevious className="left-12" />
              <CarouselNext className="right-12" />
            </>
          )}
        </Carousel>
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none" />
      </div>

      <div className="container mx-auto -mt-20 px-4 sm:px-6 lg:px-8">
        <div className="relative grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-xl border-none">
              <CardHeader className="p-8">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="secondary" className="bg-primary/5 text-primary border-none">
                        <Eye className="h-3 w-3 mr-1" /> {property.viewCount || 0} views
                      </Badge>
                      {property.reviewCount ? (
                         <Badge variant="secondary" className="bg-accent/10 text-accent border-none font-bold">
                          <Star className="h-3 w-3 mr-1 fill-accent" /> {property.reviewCount} Reviews
                        </Badge>
                      ) : null}
                    </div>
                    <CardTitle className="text-3xl font-extrabold text-primary">{property.title}</CardTitle>
                    <p className="text-lg text-muted-foreground">{property.location}</p>
                  </div>
                  <div className="flex flex-col items-end">
                    <p className="text-3xl font-black text-accent">
                      {formatCurrency(property.price)}
                    </p>
                    <p className="text-sm font-medium text-muted-foreground capitalize">per {property.period === 'yr' ? 'year' : 'month'}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-8 pt-0 space-y-8">
                 <div className="flex flex-wrap items-center gap-8 py-6 border-y">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Building className="h-6 w-6 text-primary" />
                    </div>
                    <span className="font-bold text-lg">{property.type}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <BedDouble className="h-6 w-6 text-primary" />
                    </div>
                    <span className="font-bold text-lg">{property.beds} Bedrooms</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Bath className="h-6 w-6 text-primary" />
                    </div>
                    <span className="font-bold text-lg">{property.baths} Bathrooms</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-primary mb-4">About this property</h3>
                  <p className="text-muted-foreground leading-relaxed text-lg whitespace-pre-wrap">
                    {property.description}
                  </p>
                </div>

                 {property.amenities && property.amenities.length > 0 && (
                  <div>
                    <h3 className="text-xl font-bold text-primary mb-4">Amenities</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {property.amenities.map((amenity) => (
                        <AmenityIcon key={amenity} amenity={amenity as any} />
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-8 border-t">
                  <ReviewSection propertyId={id} />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Listed by</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLandlordLoading ? (
                  <Skeleton className="h-12 w-full" />
                ) : landlord ? (
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center">
                      <UserIcon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg flex items-center gap-1">
                        {landlord.displayName || 'Property Agent'}
                        {landlord.isVerified && <ShieldCheck className="h-4 w-4 text-accent" />}
                      </h4>
                      {landlord.isVerified && <p className="text-xs text-accent font-bold">Verified Agent</p>}
                    </div>
                  </div>
                ) : null}
                
                <div className="pt-4 space-y-2">
                  <Button 
                    className="w-full h-12 text-lg font-bold" 
                    variant="default"
                    onClick={handleStartChat}
                    disabled={isStartingChat || isOwner}
                  >
                    {isStartingChat ? 'Connecting...' : 'Message Agent'}
                  </Button>
                  {landlord?.phoneNumber && (
                    <Button variant="outline" className="w-full h-12" asChild>
                      <a href={`tel:${landlord.phoneNumber}`}>
                        <Phone className="mr-2 h-4 w-4" />
                        Call Agent
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle className="text-lg">Security First</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm opacity-90">Always visit the property in person before making any payments. Report any suspicious listings.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-white/95 backdrop-blur-md p-4 pb-safe shadow-2xl">
        <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 max-w-4xl">
          <div className="hidden sm:block">
            <p className="text-sm text-muted-foreground font-medium">Interested in this property?</p>
            <p className="text-xl font-bold text-primary">{formatCurrency(property.price)} <span className="text-sm font-normal text-muted-foreground">/{property.period}</span></p>
          </div>
          <div className="flex gap-4 w-full sm:w-auto">
            <Button 
              onClick={handleStartChat} 
              disabled={isStartingChat || isOwner}
              variant="outline" 
              className="flex-1 sm:px-8 h-12 text-lg font-bold border-2"
            >
              {isStartingChat ? 'Connecting...' : isOwner ? 'Your Listing' : 'Message Agent'}
            </Button>
            
            {!isOwner ? (
              <RentNowDialog 
                property={property}
                trigger={
                  <Button variant="accent" className="flex-1 sm:px-8 h-12 text-lg font-bold shadow-lg">
                    Rent Now
                  </Button>
                }
              />
            ) : (
              <Button variant="accent" className="flex-1 sm:px-8 h-12 text-lg font-bold shadow-lg" disabled>
                Your Listing
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
